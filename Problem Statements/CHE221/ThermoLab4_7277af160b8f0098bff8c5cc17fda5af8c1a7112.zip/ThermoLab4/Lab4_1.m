clc;
clear all;
%% Problem 1 and 2

data = readmatrix('P-T-data.xlsx');

P = data(:, 2);
T = data(:, 1); 

% 1. Estimate the enthalpy of vaporization (ΔH_vap) using the Clausius-Clapeyron Equation

R = 8.314; % J/(mol·K)

% ln(P) = (ΔH_vap / R) * (1/T)
X = 1 ./ T;
Y = log(P);
coefficients = polyfit(X, Y, 1);
delta_H_vap = coefficients(1) * R; % Enthalpy of vaporization in J/mol

disp(['Estimated Enthalpy of Vaporization (ΔH_vap): ', num2str(delta_H_vap), ' J/mol']);

% 2. Fit the Antoine Equation to find the best-fit parameters (A, B, C)

% Create the model function for the Antoine Equation
antoine_model = @(coeffs, T) coeffs(1) - (coeffs(2) ./ (T + coeffs(3)));


x0 = [1, 1, 1]; 


x = lsqcurvefit(antoine_model, x0, T, log10(P));

A = x(1);
B = x(2);
C = x(3);


% Plotting the fitted Antoine Equation
figure;
plot(T, log10(P)); 
hold on
T_range = linspace(min(T), max(T), 100);
plot(T_range, antoine_model(x, T_range), 'o');
xlabel('T');
ylabel('log10(P)');
title('Antoine Equation Fit for ln(P) vs T ');



%% Problem 3

% A- Using Pen-Robenson EOS to calculate P at different data points of T

data = readmatrix('T-V (1).xlsx'); 
T_values = data(:, 1); 
V_values = data(:, 2);
R2=0.0821;
Tc=369.9;
w=0.153;
Pc = 42.5;
Vc = 0.2;
a=0.45724*R2*R2*Tc*Tc*(1/Pc);
b=0.0778 * R2*Tc*(1/Pc);

% Calculate P for each T and V using the Peng-Robenson equation of state
P_values =[];
for i=1:36
    P_values(i,:)=pengrobenson(V_values(i),T_values(i),R2,a,b,w);
end

%B Delta H vap 


X2 = 1 ./ T_values;
Y2 = log(P_values);
coefficients_2 = polyfit(X2, Y2, 1);
delta_H_vap_2 = coefficients_2(1) * R2; % Enthalpy of vaporization in J/mol


%C Antoine Paramters Estimation
antoine_model_new = @(coeffs, T_values) coeffs(1) - (coeffs(2) ./ (T_values + coeffs(3)));


x0_2 = [1,1,1]; 
lb=[-100,-1000000,-1000000];
ub=[100,100,100];

x2 = lsqcurvefit(antoine_model, x0_2, T_values, log10(P_values),lb,ub);

A_new = x2(1)
B_new = x2(2)
C_new = x2(3)


% Plot 

% Plotting the fitted Antoine Equation
figure;
plot(T_values, log10(P_values)); hold on;
T_range_new = linspace(min(T_values), max(T_values), 100);
plot(T_range_new, antoine_model_new(x2, T_range_new), 'o');
xlabel('Temperature (K)');
ylabel('log10(P)');
title('Antoine Equation Fit for ln(P) vs T _PR');

% D- Clausius Clayperon Plot
figure;
plot(X,log(P),'bo-')
xlabel('1/T');
ylabel('log(P)');
title('Clausius-Clapeyron Plot for log10(P) vs 1/T');
grid on;
figure;
plot(X2,log(P_values),'bo-')
xlabel('1/T');
ylabel('log(P)');
title('Clausius-Clapeyron Plot for log10(P) vs 1/T(_PR)');


% E  Ideal Gas Equation of State

% Calculate P for each T and V using the Ideal Gas equation of state
P_values2 =[];
for i=1:36
    P_values2(i,:)= R2*T_values(i)/V_values(i);
end

%finding Delta H vap 

% ln(P) = (ΔH_vap / R2) * (1/T)
X3 = 1 ./ T_values;
Y3 = log(P_values2);
coefficients3 = polyfit(X3, Y3, 1);
delta_H_vap_3 = coefficients3(1) * R2; % Enthalpy of vaporization in J/mol

disp(['Estimated Enthalpy of Vaporization(ΔH_vap_ideal): ', num2str(delta_H_vap_3), ' J/mol']);

% Antoine Paramters Estimation
antoine_model_new = @(coeffs, T_values) coeffs(1) - (coeffs(2) ./ (T_values + coeffs(3)));


x0_2 = [1,1,1]; 
lb=[-100,-1000000,-1000000];
ub=[100,10000000,10000];

x3 = lsqcurvefit(antoine_model, x0_2, T_values, log10(P_values2),lb,ub);

A_newer = x3(1)
B_newer = x3(2)
C_newer = x3(3)



% Plot for given data 

% Plotting the fitted Antoine Equation
figure;
plot(T_values, log10(P_values2)); hold on;
T_range_new = linspace(min(T_values), max(T_values), 100);
plot(T_range_new, antoine_model_new(x3, T_range_new), 'o');
xlabel('Temperature (K)');
ylabel('log10(P)');
title('Antoine Equation Fit for ln(P) vs T for Ideal Gas');


function P = pengrobenson(V, T, R, a ,b, w)
    % Peng-Robenson equation of state
    Tc = 369.9;
    Tr = T / Tc;
    alpha = (1 + (0.37464 + 1.54226 * w - 0.26992 * w.^2) * ((1 - Tr).^0.5)).^2;
    Ptemp = R * T ./ (V - b) - a * alpha ./ (V.^2 + 2 * b * V - b^2);
    P = Ptemp / (1.01325 * 1e5); % Convert pressure to atm
end
