clc
clear

%% Reading data
data1 = readmatrix("LabThermo5/P-V.csv");
data2 = readmatrix("LabThermo5/Z-P.csv");

%%Q1a
% Calculating Fugacity coeff 
Z = data2(:,2);
P = data2(:,1);
phi_exp = data2(:,3);

for i = 2:size(P)
   X = P(1:i);%
   Y = (Z(1:i)-1)./X;
   ln_phi_cal(i) = trapz(X,Y);
end
phi_cal = exp(ln_phi_cal);

figure
plot(P,phi_exp)
hold on
plot(P,phi_cal)
xlabel("Pressure")
ylabel("Fugacity Coefficient")
legend('Experimental','Calculated')


%% Q1b
% vander Waals equation of state
P1 = data1(:,1);
V1 = data1(:,2);


R = 0.083;
Tc = 405.6; %K
Pc = 111.5; %atm
a = 27*(R*Tc)^2/(64*Pc);
b = R*Tc/(8*Pc);
N = 1;

T = 373;





for i = 1:size(P1)
    V_ideal = R*T./P1(i);
    fun = @(V)(P1(i)+a./V^2).*(V-b)-R*T;
    v_sol = fsolve(fun,V_ideal);
    v_van(i) = max(v_sol);
    z(i) = V1(i)./v_van(i);
    
end

ln_phi_van = log(v_van./v_van-b)+(b./v_van-b)-2*a./v_van*R*T-log(z);

del_g = R*T*ln_phi_van;

%% Q3

a1 = 0.45724*R^2*T^2/Pc;
b1 = 0.0778*R*Tc/Pc;

w = 0.253;
Tr = T / Tc;
k = (1 + (0.37464 + 1.54226 * w - 0.26992 * w.^2) * ((1 - Tr).^0.5)).^2;
alpha = (1+k*(1+(T/Tc))^0.5)^2;


for i = 1:size(P1)
    V_ideal = R*T./P1(i);
    fun1 = @(Vpr)(R*T./Vpr-b1)-a1*alpha./2.*2^1./2.*b1*R*T(1-2*alpha).*log((vpr+(1+2^1/2).*b1)./(vpr+(1-2^1/2).*b1));
    v_sol1 = fsolve(fun1,V_ideal);
    v_pr(i) = max(v_sol1);
    z1(i) = V1(i)./v_pr(i);
    
end



























% V_vander(size(P1)) = R*T./(P1(size(P1))+a./V1(size(P1)).^2)+b;
% V_vander_trans = transpose(V_vander);
% 
% z = a-1./V1*R*T;
% 
% 
% for j = 1:size(P1)
%     ln_phi1(j) = log(V1(j)./V1(j)-b)+b./V1(i)-b-2*a./V1(j)*R*T-log(z);
% end




