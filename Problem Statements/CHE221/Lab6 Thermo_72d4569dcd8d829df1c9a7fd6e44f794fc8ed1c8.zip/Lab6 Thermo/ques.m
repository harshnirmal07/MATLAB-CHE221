clc

%% Defining Antoine Parameters
Water_A = 8.07131;
Water_B = 1730.63;
Water_C = 233.426;

Ethanol_A = 8.2133;
Ethanol_B = 1652.05;
Ethanol_C = 231.48;

P_total = 1;%atm

Tb_water = 100;
Tb_ethanol = 78.23;

T = linspace(Tb_ethanol,Tb_water,100);

P_i_vap_water = (10.^(Water_A - Water_B./(Water_C+T)))/760;


P_i_vap_ethanol = (10.^(Ethanol_A-Ethanol_B./(Ethanol_C+T)))/760;


xi_water = (1-P_i_vap_ethanol)./(P_i_vap_water-P_i_vap_ethanol);
xi_ethanol = 1-xi_water;
yi_water = (xi_water.*P_i_vap_water)./P_total;
yi_ethanol = (xi_ethanol.*P_i_vap_ethanol)./P_total;

figure(1)
plot(xi_water,T)
hold on
plot(yi_water,T)
xlabel("xi,yi")
ylabel("Temperature")
title("T-x-y Plot for water")



figure(2)
plot(xi_ethanol,T)
hold on
plot(yi_ethanol,T)
xlabel("xi,yi")
ylabel("Temperature")
title("T-x-y Plot for ethanol")

figure(3)
plot(xi_ethanol,yi_ethanol)
xlabel("Mole fraction")
ylabel("Vapour")
title("x-y")
legend ("Liquid")



%% Question 3 Water at 50 c
x = linspace(0,1,100);

P_i_vap_water_1 = (10.^(Water_A - Water_B./(Water_C+50)))/760;
P_i_vap_ethanol_1 = (10.^(Ethanol_A-Ethanol_B./(Ethanol_C+50)))/760;

P_total_new = (P_i_vap_water_1).*x + (1-x).*P_i_vap_ethanol_1;

yi_3 = x.*P_i_vap_water_1./P_total_new;
xi_3 = (1-P_i_vap_ethanol_1)./(P_i_vap_water_1-P_i_vap_ethanol_1);

figure(4)
plot(P_total_new,yi_3)
hold on
plot(P_total_new,x)
xlabel("PTotal")
ylabel("x,y")
title("P-x-y at Temp 50 cel")


