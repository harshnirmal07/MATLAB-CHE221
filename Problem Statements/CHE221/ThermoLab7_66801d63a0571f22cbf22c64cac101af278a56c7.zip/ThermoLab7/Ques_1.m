clc
clear 

CompA = [4.42448 5.20409];
CompB = [1312.253 1581.341];
CompC = [-32.445 -33.50];
Tc = [508 513];
Pc = [48e5 81e5];
R = 8.314;
a = (27*(R*Tc).^2)./(64*Pc);
b = (R*Tc)./(8*Pc);
T = 328.15;

data = readmatrix("data.xlsx");

%% Segregation
x1_exp = data(:,1);
y1_exp = data(:,2);
Pt_exp = data(:,3)*1e3;
P1_sat = (10^(CompA(1)-(CompB(1)/(T+CompC(1)))))*1e5;
P2_sat = (10^(CompA(2)-(CompB(2)/(T+CompC(2)))))*1e5;
y1_sim = zeros(size(Pt_exp));
P = x1_exp.*P1_sat+(1-x1_exp).*P2_sat;

for i = 1:size(x1_exp)
    V(i) = fsolve(@(V)((P(i)+(a(1)/V^2))*(V-b(1))-R*T),R*T/Pt_exp(i));
    phi1(i) = exp((-1)*(log(1-(b(1)/V(i)))   +  (a(1)/(V(i)*R*T))  + log((P(i)*V(i))/(R*T))   +   (1-((P(i)*V(i))/(R*T)))));
    y1_sim(i) = x1_exp(i)*P1_sat/(phi1(i)*P(i));
end
figure(1)
plot(y1_sim,Pt_exp,y1_exp,Pt_exp)


figure(2)
plot(y1_sim,P,y1_exp,P)
xlabel('y')
ylabel('P_sim')

figure(3)
plot(Pt_exp,P)
xlabel('P_exp')
ylabel('P')

figure(4)
plot(y1_exp,y1_sim)

xlabel('y1_exp')
ylabel('y1_sim')
