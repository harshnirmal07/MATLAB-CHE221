clc
Cp_Steel = 0.5 %kJ/kg*K
Cp_oil = 2.5 %KJ/kg*K

m_steel = 40; %kg
m_oil = 150;
T1 = 450 + 273.15; %K
T2 = 25+273.15; %K

% Energy Balance ;delQ = 0

T_final = (m_steel*Cp_Steel*T1 + m_oil*Cp_oil*T2)/(m_steel*Cp_Steel + m_oil*Cp_oil);

%Casting S = m*cp*ln(t2/t)
delS1 = m_steel*Cp_Steel*log(T_final/T1)


%Oil
delS2 = m_oil*Cp_oil*log(T_final/T2)

%Total Entropy
S_total = delS2+delS1 %KJ/Kg*K

