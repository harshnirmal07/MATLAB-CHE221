clear all
clc

Pow = 800000 ; % kW
T_h = 585 ; %K
T_l = 295 ; %K
n= 0.7 ; 

Eff = n*(1-T_l/T_h) % Second Law

Q_in = Pow/Eff %kW

Q_out  = Q_in - Pow %kW