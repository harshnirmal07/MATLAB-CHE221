clc
clear 

%% Given data
THF_literature = [
0.00	0.0000
0.02	0.6523
0.04	0.7381
0.06	0.7516
0.08	0.7562
0.10	0.7587
0.15	0.7618
0.20	0.7625
0.25	0.7629
0.30	0.7635
0.35	0.7639
0.40	0.7643
0.45	0.7649
0.50	0.7658
0.55	0.7684
0.60	0.7720
0.65	0.7765
0.70	0.7831
0.75	0.7915
0.80	0.8085
0.82	0.8180
0.84	0.8260
0.86	0.8368
0.88	0.8498
0.90	0.8660
0.92	0.8855
0.94	0.9070
0.96	0.9325
0.98	0.9625
0.99	0.9805
1.00	1.0000
] ;

water_data = [373.15	0.00
349.64	0.01
343.73	0.02
341.44	0.03
340.32	0.04
339.68	0.05
339.28	0.06
339.00	0.07
338.81	0.08
338.67	0.09
338.55	0.10
338.46	0.11
338.39	0.12
338.32	0.13
338.27	0.14
338.22	0.15
338.17	0.16
338.13	0.17
338.09	0.18
338.05	0.19
338.02	0.20
337.99	0.21
337.95	0.22
337.92	0.23
337.89	0.24
337.86	0.25
337.83	0.26
337.80	0.27
337.77	0.28
337.75	0.29
337.72	0.30
337.69	0.31
337.66	0.32
337.63	0.33
337.60	0.34
337.57	0.35
337.54	0.36
337.51	0.37
337.48	0.38
337.45	0.39
337.42	0.40
337.39	0.41
337.36	0.42
337.33	0.43
337.30	0.44
337.27	0.45
337.24	0.46
337.21	0.47
337.17	0.48
337.14	0.49
337.11	0.50
337.08	0.51
337.04	0.52
337.01	0.53
336.98	0.54
336.94	0.55
336.91	0.56
336.88	0.57
336.84	0.58
336.81	0.59
336.77	0.60
336.74	0.61
336.71	0.62
336.67	0.63
336.64	0.64
336.61	0.65
336.57	0.66
336.54	0.67
336.51	0.68
336.47	0.69
336.44	0.70
336.41	0.71
336.38	0.72
336.35	0.73
336.32	0.74
336.29	0.75
336.27	0.76
336.24	0.77
336.22	0.78
336.20	0.79
336.18	0.80
336.17	0.81
336.16	0.82
336.15	0.83
336.15	0.84
336.15	0.85
336.16	0.86
336.18	0.87
336.20	0.88
336.24	0.89
336.28	0.90
336.34	0.91
336.42	0.92
336.51	0.93
336.62	0.94
336.76	0.95
336.92	0.96
337.12	0.97
337.36	0.98
337.65	0.99
338.00	1.00
];

%%
R = 1.987;
T = 1;
% Wilson Parameters
Para1 = 1475.26; %cal/mol
Para2 = 1844.79;
Vi = 81.55; %cm3/mol
Vj = 18.07;

delij = (Vj/Vi)*exp(-Para1/R*T);

THF_A = 7.1057;
THF_B = 1256.68;
THF_C = 232.621;

Water_A = 8.07131;
Water_B = 1730.63;
Water_C = 233.426;

xj = water_data(:,2);
xi = 1-xj;

T = water_data(:,1);
for i = 1:size(xj)
    pvap_THF(i) = 10^(THF_A - THF_B./(THF_C+T(i)-273.15))/760;
    pvap_Water(i) = 10^(Water_A - Water_B./(Water_C+T(i)-273.15))/760;

    lambda_ij(i) = (Vj/Vi)*exp(-(Para1)/(R*T(i)));
    lambda_ji(i) = (Vi/Vj)*exp(-(Para2)/(R*T(i)));
    gamma_i(i) = exp(-log(xi(i)+lambda_ij(i))*xi(i)-xj(i)*(lambda_ij(i)./(xi(i)+lambda_ij(i)*xj(i))-lambda_ji(i)./(xj(i)+lambda_ji(i)*xi(i))));
    gamma_j(i) = exp(-log(xj(i)+lambda_ji(i))*xi(i)-xi(i)*(lambda_ij(i)./(xi(i)+lambda_ij(i)*xj(i))-lambda_ji(i)./(xj(i)+lambda_ji(i)*xi(i))));
    yj(i) = gamma_j(i)*xj(i)*pvap_Water(i);
    yi(i) = 1-yj(i);
%     P = (gamma_i(i).*xi(i).*pvap_Water(i))./(yi);
end

figure(1)
plot(xi,T)
hold on
plot(yi,T)
xlabel("Mole fraction")
ylabel("Temp")
title("T-x-y for THF")
legend("Liq","Vap")

figure(2)
plot(xj,T)
hold on
plot(yj,T)
xlabel("Mole fraction")
ylabel("Temp")
title("T-x-y for water")

%% Part B
figure(3)
plot(THF_literature(:,1),THF_literature(:,2));
hold on
plot(xi,yi);
xlabel("x1")
ylabel("y1")
title("xy Diagram using Wilson Model")

%% Part C for T = 50 cel 
xwater = linspace(0,1,100);

pvap_Water1 = 10^(Water_A - Water_B./(Water_C+50))/760;
lambda_ij_1 = (Vj/Vi)*exp(-(Para1)/(R*50));
lambda_ji_2 = (Vi/Vj)*exp(-(Para2)/(R*50));

for i = 1:size(xwater)
    pvap_THF(i) = 10^(THF_A - THF_B./(THF_C+50))/760;
   

  
    gamma_i(i) = exp(-log(xi(i)+lambda_ij(i))*xi(i)-xj(i)*(lambda_ij(i)./(xi(i)+lambda_ij(i)*xj(i))-lambda_ji(i)./(xj(i)+lambda_ji(i)*xi(i))));
    gamma_j(i) = exp(-log(xj(i)+lambda_ji(i))*xi(i)-xi(i)*(lambda_ij(i)./(xi(i)+lambda_ij(i)*xj(i))-lambda_ji(i)./(xj(i)+lambda_ji(i)*xi(i))));
    yj(i) = gamma_j(i)*xj(i)*pvap_Water1;
    yi(i) = 1-yj(i);
%     P = (gamma_i(i).*xi(i).*pvap_Water(i))./(yi);
end








